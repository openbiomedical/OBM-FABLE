/*
 FastSend function
 
Acquire and send to a host computer via serial an Analog pin at 2Khz and 16 bit resolution.
Require a serial connection at least at 115200.
Use COBS encode to packet the data

2016 - Alessandro Ricco
*/
#ifndef FastSend_h
#define FastSend_h

#include "Arduino.h"

static size_t COBSencode(const uint8_t* source, size_t size, uint8_t* destination)
    {
        size_t read_index  = 0;
        size_t write_index = 1;
        size_t code_index  = 0;
        uint8_t code       = 1;

        while(read_index < size)
        {
            if(source[read_index] == 0)
            {
                destination[code_index] = code;
                code = 1;
                code_index = write_index++;
                read_index++;
            }
            else
            {
                destination[write_index++] = source[read_index++];
                code++;

                if(code == 0xFF)
                {
                    destination[code_index] = code;
                    code = 1;
                    code_index = write_index++;
                }
            }
        }
        destination[code_index] = code;
        return write_index;
    }


class FastSend
{
  public:
    void send();
  private:
    
};

#endif