/*
 FastSend function
 
Acquire and send to a host computer via serial an Analog pin at 2Khz and 16 bit resolution.
Require a serial connection at least at 115200.
Use COBS encode to packet the data

2016 - Alessandro Ricco

*/

//COBS encode function//

// Copyright (c) 2010-2014 Christopher Baker <http://christopherbaker.net>
//
// Portions:
//  Copyright (c) 2011, Jacques Fortier. All rights reserved.
//  https://github.com/jacquesf/COBS-Consistent-Overhead-Byte-Stuffing


#include "Arduino.h"
#include "FastSend.h"

void FastSend::send()
{
  //send cobs data
int samples = 64; // total number of samples in one packet
int samples_b = samples * 2; // bytes for all samples, 2 byte for each sample
int esize = 0; // size of the COBS encoded packet
uint8_t raw[samples_b]; // buffer for raw (non encoded) data
uint8_t enc[samples_b+2]; // buffer for COBS encoded data

int i;

for (i = 0; i < samples; i = i + 1) {

  word AnalogVal = word(analogRead(0)); // acquire analog 0 as 16 bit value
  raw[i*2] = highByte(AnalogVal); // split on 2 bytes
  raw[i*2+1] = lowByte(AnalogVal);
  Serial.write(enc[i*2]); // send 2 bytes encodend from the previous run of acquisitions
  Serial.write(enc[i*2+1]);
  //delay(1);
  delayMicroseconds(380); //to tune the loop at 500us (Analog read require about 100us)
  }
Serial.write(enc[samples_b]); // send last couple of COBS packet
Serial.write(enc[samples_b+1]); // send last couple of COBS packet
delayMicroseconds(380);
 
memset(enc,0,sizeof(enc)); // clear COBS buffer array
esize = COBSencode (raw,samples_b,enc); // calculate COBS for the new raw data, this will be send during the next acquisition run

}

